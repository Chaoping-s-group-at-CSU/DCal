mkdir 0-A
cd 0-A
cp ../w0/CONTCAR POSCAR-0
cp ../wA/CONTCAR POSCAR-1
nebmake.pl POSCAR-0 POSCAR-1 3
cp ../w0/POTCAR .
cp /public/home/hpc8204181713/diffusion/L12/Al3Ti/Ti/0-1/INCAR .
cp /public/home/hpc8204181713/diffusion/HCP/Ti-Al/ori/KPOINTS .
cp /public/home/hpc8204181713/diffusion/L12/Al3Ti/Ti/0-1/job.sh .
#sbatch -A pi_liangchaoping_d -p liangchaopingQ -q liangchaopingq job.sh
sbatch job.sh
cd ..

mkdir 0-B
cd 0-B
cp ../w0/CONTCAR POSCAR-0
cp ../wB/CONTCAR POSCAR-1
nebmake.pl POSCAR-0 POSCAR-1 3
cp ../w0/POTCAR .
cp /public/home/hpc8204181713/diffusion/L12/Al3Ti/Ti/0-1/INCAR .
cp /public/home/hpc8204181713/diffusion/HCP/Ti-Al/ori/KPOINTS .
cp /public/home/hpc8204181713/diffusion/L12/Al3Ti/Ti/0-1/job.sh .
#sbatch -A pi_liangchaoping_d -p liangchaopingQ -q liangchaopingq job.sh
sbatch job.sh
cd ..

