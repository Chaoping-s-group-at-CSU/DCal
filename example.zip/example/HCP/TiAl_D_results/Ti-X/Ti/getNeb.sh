
cd 0-A
cp neb.dat oldneb.dat
cp ../w0/OUTCAR ./00/.
cp ../wA/OUTCAR ./04/.
nebresults.pl
cd ..

cd 0-B
cp neb.dat oldneb.dat
cp ../w0/OUTCAR ./00/.
cp ../wB/OUTCAR ./04/.
nebresults.pl
cd ..

