function Ffactor
%Calculate the Ffactor of impurity diffusion
%Read w-factors
B=0.736;
A=dlmread('CONTCAR','',[2,0,2,0]);a=2*A/3;
wA=dlmread('0To9.dat');
wap=dlmread('0To6.dat');
wbp=dlmread('0To7.dat');
wcp=dlmread('0To8.dat');
wB=dlmread('1To5.dat');
wa=dlmread('1To2.dat');
wb=dlmread('1To3.dat');
wc=dlmread('1To4.dat');
wA=wA(:,4);wap=wap(:,4);wbp=wbp(:,4);wcp=wcp(:,4);wB=wB(:,4);wa=wa(:,4);wb=wb(:,4);wc=wc(:,4);
for i = length (wa)
   x0=[0;0;0];
   options = optimoptions('fsolve','Display','iter','MaxFunEvals',20000,'OptimalityTolerance',1e-40,'FunctionTolerance',1e-40,'StepTolerance',1e-40);
   [x,fval] = fsolve(@myfun,x0,options);
   fbz=(2*wap+7*B*wcp)/(2*wA+2*wap+7*B*wcp);
   fbx=1+2*x(1)/(a/(3^0.5));
   fax=1+2*x(2)/a;
% for i=1:length(wA)
%     if (zero(i)==0 || two(i)==0 || three(i)==0) || four(i)==0|| five(i)==0 ||threep(i)==0 )
%         f(i)=0;
%     else
%         F(i)=((331.14*(four(i)/five(i))^2+857.93*(four(i)/five(i))+409.95)/(165.57*(four(i)/five(i))+134.2))/7;
%         f(i)=(7*threep(i)*F(i))/(2*two(i)+7*threep(i)*F(i));
%     end
% end
% tem=0:10:2800;
% tem=tem';f=f';
% for i=1:length(f)
%     if f(i)==0
%         continue
%     else
%         t=i;
%         break
%     end
% end
% tinv=1./tem;ffit=log(f); 
% C=polyfit(tinv(t:end),ffit(t:end),2);
% C=polyder(C);ztemp=zeros(t-1,1);
% cout=polyval(C,tinv(t:end));cout=cat(1,ztemp,cout);cout=cout*8.617343*10^(-5);
factor=table(fbz,fbx,fax);
factor=table2cell(factor);
xlswrite('f-Factor.xls', factor);


function F=myfun(x)
%x1 is Sbx; x2 is Sax; x3 is Say
B=0.736;
A=dlmread('CONTCAR','',[2,0,2,0]);a=2*A/3;
for i = length ()
F=[x(1)-(2*wap*(3^0.5*x(2)/2+x(3)/2)+2*B*wbp*(-0.5)*x(1)-wA*(x(1)+a/(3^0.5)))/(2*wap+2*wbp+7*B*wc+wA);...
    x(2)-(2*wa*3^0.5/2*x(1)+2*wb*0.5*x(2)-wB*(a+x(2)))/(2*wa+2*wb+7*B*wc+wB);...
    x(3)-(2*wa*0.5*x(1)+2*wb*(-0.5)*x(3))/(2*wa+2*wb+7*B*wc+wB)];
